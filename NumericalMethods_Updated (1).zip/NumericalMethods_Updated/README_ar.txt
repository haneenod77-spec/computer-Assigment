واجهة الطرق العددية — النسخة المحدّثة

لتشغيلها على Windows افتحي Terminal داخل هذا المجلد ثم اكتبي:
py NumericalMethods_Updated.py

أو من أي مجلد شغّليها بالمسار الكامل:
py "%USERPROFILE%\Downloads\NumericalMethods_Updated\NumericalMethods_Updated.py"

إذا كان مجلد التنزيل مختلفاً، استخدمي مسار الملف حيث فككت الضغط.
البرنامج يحتوي الطرق العددية التسع، وصفحات إدخال مستقلة، وجدول تتبّع يظهر بعد الحساب.
يتطلب Python مع Tkinter.
