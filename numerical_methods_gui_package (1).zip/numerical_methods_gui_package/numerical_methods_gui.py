import ast
import math
import tkinter as tk
from tkinter import ttk, messagebox

# Safe mathematical expression evaluator; supports x, standard math functions, and ^ as **.
_ALLOWED_FUNCS = {name: getattr(math, name) for name in
                  ('sin cos tan asin acos atan sinh cosh tanh exp log log10 sqrt'
                   ' floor ceil factorial radians degrees').split()}
_ALLOWED_FUNCS.update({'abs': abs, 'min': min, 'max': max})
_ALLOWED_CONSTS = {'pi': math.pi, 'e': math.e}

def f_eval(expr, x):
    tree = ast.parse(expr.replace('^', '**'), mode='eval')
    def ev(n):
        if isinstance(n, ast.Expression): return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)): return n.value
        if isinstance(n, ast.Name):
            if n.id == 'x': return x
            if n.id in _ALLOWED_CONSTS: return _ALLOWED_CONSTS[n.id]
            if n.id in _ALLOWED_FUNCS: return _ALLOWED_FUNCS[n.id]
            raise ValueError('اسم غير مسموح: ' + n.id)
        if isinstance(n, ast.BinOp) and type(n.op) in (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.Mod):
            a, b = ev(n.left), ev(n.right)
            return {ast.Add: lambda: a+b, ast.Sub: lambda: a-b, ast.Mult: lambda: a*b,
                    ast.Div: lambda: a/b, ast.Pow: lambda: a**b, ast.Mod: lambda: a%b}[type(n.op)]()
        if isinstance(n, ast.UnaryOp) and type(n.op) in (ast.UAdd, ast.USub):
            return ev(n.operand) if isinstance(n.op, ast.UAdd) else -ev(n.operand)
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in _ALLOWED_FUNCS:
            return _ALLOWED_FUNCS[n.func.id](*(ev(a) for a in n.args))
        raise ValueError('صيغة رياضية غير مدعومة')
    return float(ev(tree))

def rows_matrix(text):
    rows = [[float(v) for v in line.replace(',', ' ').split()] for line in text.strip().splitlines() if line.strip()]
    if not rows or any(len(r) != len(rows[0]) for r in rows): raise ValueError('أدخل المصفوفة صفاً في كل سطر وبأبعاد متساوية.')
    return rows

def determinant(a):
    m = [r[:] for r in a]; n = len(m); d = 1.0
    if any(len(r) != n for r in m): raise ValueError('المصفوفة يجب أن تكون مربعة.')
    for k in range(n):
        p = max(range(k, n), key=lambda i: abs(m[i][k]))
        if abs(m[p][k]) < 1e-14: return 0.0
        if p != k: m[k], m[p] = m[p], m[k]; d *= -1
        pivot = m[k][k]; d *= pivot
        for i in range(k+1, n):
            q = m[i][k] / pivot
            for j in range(k+1, n): m[i][j] -= q*m[k][j]
    return d

def parse_vector(text):
    return [float(v) for v in text.replace(',', ' ').split()]

def solve(method, v):
    trace, result = [], ''
    if method == 'kramer':
        a = rows_matrix(v['A']); b = parse_vector(v['b']); n = len(a)
        if len(b) != n or any(len(r) != n for r in a): raise ValueError('عدد عناصر b يجب أن يطابق أبعاد المصفوفة المربعة A.')
        d = determinant(a)
        if abs(d) < 1e-14: raise ValueError('المحدد يساوي صفراً؛ لا يوجد حل وحيد بطريقة كرامر.')
        x = []
        for j in range(n):
            aj = [r[:] for r in a]
            for i in range(n): aj[i][j] = b[i]
            dj = determinant(aj); x.append(dj/d)
            trace.append((f'x{j+1}', f'det(A{j+1}) = {dj:.8g}', f'x{j+1} = {dj:.8g} / {d:.8g} = {x[-1]:.8g}'))
        result = 'الحل: [' + ', '.join(f'{z:.10g}' for z in x) + ']'
    elif method == 'gauss':
        a = rows_matrix(v['A']); b = parse_vector(v['b']); n = len(a)
        if len(b) != n or any(len(r) != n for r in a): raise ValueError('أبعاد A و b غير متوافقة.')
        m = [a[i][:] + [b[i]] for i in range(n)]
        for k in range(n-1):
            p = max(range(k, n), key=lambda i: abs(m[i][k]))
            if abs(m[p][k]) < 1e-14: raise ValueError('النظام مفرد أو لا يملك حلاً وحيداً.')
            m[k], m[p] = m[p], m[k]
            for i in range(k+1, n):
                q = m[i][k]/m[k][k]
                for j in range(k, n+1): m[i][j] -= q*m[k][j]
            trace.append((f'حذف {k+1}', f'المحور = {m[k][k]:.6g}', ' | '.join(' '.join(f'{z:.5g}' for z in r) for r in m)))
        if abs(m[-1][-2]) < 1e-14: raise ValueError('النظام مفرد أو لا يملك حلاً وحيداً.')
        x = [0.0]*n
        for i in range(n-1, -1, -1): x[i] = (m[i][-1]-sum(m[i][j]*x[j] for j in range(i+1,n)))/m[i][i]
        trace.append(('تعويض خلفي', 'الحل', ', '.join(f'x{i+1}={z:.8g}' for i,z in enumerate(x))))
        result = 'الحل: [' + ', '.join(f'{z:.10g}' for z in x) + ']'
    elif method == 'trap':
        a,b,n = float(v['a']),float(v['b']),int(v['n']); expr=v['f']
        if n < 1: raise ValueError('n يجب أن يكون عدداً صحيحاً موجباً.')
        h=(b-a)/n; total=0.0
        for i in range(n+1):
            xx=a+i*h; yy=f_eval(expr,xx); w=0.5 if i in (0,n) else 1.0; part=w*yy; total+=part
            trace.append((i, f'{xx:.8g}', f'{yy:.8g}', f'{w:g}', f'{part:.8g}'))
        result=f'قيمة التكامل التقريبية = {h*total:.12g} (h = {h:.8g})'
    elif method in ('bisect','newton','secant'):
        expr=v['f']; tol=float(v['tol']); limit=int(v['maxit'])
        if tol<=0 or limit<1: raise ValueError('التسامح وعدد التكرارات يجب أن يكونا موجبين.')
        def ff(z): return f_eval(expr,z)
        if method=='bisect':
            a,b=float(v['a']),float(v['b']); fa,fb=ff(a),ff(b)
            if fa*fb>0: raise ValueError('يجب أن تتغير إشارة f بين a و b.')
            p=a
            for k in range(1,limit+1):
                p=(a+b)/2; fp=ff(p); err=abs(b-a)/2
                trace.append((k,f'{a:.8g}',f'{b:.8g}',f'{p:.10g}',f'{fp:.6g}',f'{err:.4g}'))
                if abs(fp)<tol or err<tol: break
                if fa*fp<0: b=p; fb=fp
                else: a=p; fa=fp
        elif method=='newton':
            x=float(v['x0']); de=v.get('df','').strip()
            def df(z): return f_eval(de,z) if de else (ff(z+1e-6)-ff(z-1e-6))/2e-6
            p=x
            for k in range(1,limit+1):
                fx=ff(x); dfx=df(x)
                if abs(dfx)<1e-14: raise ValueError('المشتقة تساوي صفراً؛ تعذر إكمال نيوتن.')
                p=x-fx/dfx; err=abs(p-x)
                trace.append((k,f'{x:.10g}',f'{fx:.6g}',f'{dfx:.6g}',f'{p:.10g}',f'{err:.4g}'))
                if abs(ff(p))<tol or err<tol: break
                x=p
        else:
            x0,x1=float(v['x0']),float(v['x1']); p=x1
            for k in range(1,limit+1):
                f0,f1=ff(x0),ff(x1); den=f1-f0
                if abs(den)<1e-14: raise ValueError('تعذر القسمة: قيمتا الدالة متساويتان تقريباً.')
                p=x1-f1*(x1-x0)/den; err=abs(p-x1)
                trace.append((k,f'{x0:.8g}',f'{x1:.8g}',f'{ff(p):.6g}',f'{p:.10g}',f'{err:.4g}'))
                if abs(ff(p))<tol or err<tol: break
                x0,x1=x1,p
        result=f'الجذر التقريبي = {p:.12g} ؛ f(x) = {ff(p):.5g} ؛ عدد التكرارات = {len(trace)}'
    elif method == 'diff':
        expr=v['f']; x=float(v['x0']); h=float(v['h']); mode=v['mode']
        if h==0: raise ValueError('h لا يجوز أن يساوي صفراً.')
        if mode=='مركزي': val=(f_eval(expr,x+h)-f_eval(expr,x-h))/(2*h)
        elif mode=='أمامي': val=(f_eval(expr,x+h)-f_eval(expr,x))/h
        else: val=(f_eval(expr,x)-f_eval(expr,x-h))/h
        trace=[('f(x)',f'{f_eval(expr,x):.10g}'),('f(x+h)',f'{f_eval(expr,x+h):.10g}'),('f(x-h)',f'{f_eval(expr,x-h):.10g}'),('h',h),('نوع الفرق',mode),('المشتقة التقريبية',f'{val:.12g}')]
        result=f"f'({x:g}) ≈ {val:.12g}"
    elif method == 'jacobi':
        a=rows_matrix(v['A']); b=parse_vector(v['b']); x=parse_vector(v['x0']); n=len(a); tol=float(v['tol']); limit=int(v['maxit'])
        if len(b)!=n or len(x)!=n or any(len(r)!=n for r in a): raise ValueError('أبعاد A و b والتخمين الابتدائي غير متوافقة.')
        if tol<=0 or limit<1: raise ValueError('التسامح وعدد التكرارات يجب أن يكونا موجبين.')
        for it in range(1,limit+1):
            xn=[]
            for i in range(n):
                if abs(a[i][i])<1e-14: raise ValueError('عنصر قطري صفري في A؛ لا يمكن تطبيق جاكوبي.')
                xn.append((b[i]-sum(a[i][j]*x[j] for j in range(n) if j!=i))/a[i][i])
            err=max(abs(xn[i]-x[i]) for i in range(n)); trace.append((it,*[f'{z:.8g}' for z in xn],f'{err:.4g}'))
            x=xn
            if err<tol: break
        result='الحل التقريبي: ['+', '.join(f'{z:.10g}' for z in x)+f'] ؛ عدد التكرارات = {len(trace)}'
    elif method == 'lagrange':
        xs=parse_vector(v['xs']); ys=parse_vector(v['ys']); x=float(v['x'])
        if len(xs)!=len(ys) or len(xs)<2: raise ValueError('يجب أن يتساوى عدد قيم x و y (قيمتان على الأقل).')
        if len(set(xs))!=len(xs): raise ValueError('قيم x يجب أن تكون مختلفة.')
        total=0.0
        for i in range(len(xs)):
            li=1.0
            for j in range(len(xs)):
                if i!=j: li *= (x-xs[j])/(xs[i]-xs[j])
            term=ys[i]*li; total+=term; trace.append((i+1,f'{xs[i]:g}',f'{ys[i]:g}',f'{li:.8g}',f'{term:.8g}'))
        result=f'P({x:g}) = {total:.12g}'
    return result, trace

METHODS = {
 'كramer': ('قاعدة كرامر — حل نظام خطي', [('A','مصفوفة المعاملات A (صف لكل سطر)'),('b','متجه الثوابت b')], ['العمود','المحدد','الحساب']),
 'gauss': ('الحذف الغاوسي — حل نظام خطي', [('A','مصفوفة المعاملات A (صف لكل سطر)'),('b','متجه الثوابت b')], ['الخطوة','المحور/النتيجة','المصفوفة الموسعة']),
 'trap': ('قاعدة شبه المنحرف — تكامل عددي', [('f','الدالة f(x)'),('a','الحد الأدنى a'),('b','الحد الأعلى b'),('n','عدد الفترات n')], ['i','xᵢ','f(xᵢ)','الوزن','المساهمة']),
 'bisect': ('طريقة التنصيف — إيجاد جذر', [('f','الدالة f(x)'),('a','طرف الفترة a'),('b','طرف الفترة b'),('tol','التسامح ε'),('maxit','أقصى عدد تكرارات')], ['k','a','b','p','f(p)','الخطأ']),
 'newton': ('طريقة نيوتن — إيجاد جذر', [('f','الدالة f(x)'),('df','المشتقة f′(x) (اختياري؛ تقدر عددياً إن تُركت فارغة)'),('x0','التخمين الابتدائي x₀'),('tol','التسامح ε'),('maxit','أقصى عدد تكرارات')], ['k','xₖ','f(xₖ)','f′(xₖ)','xₖ₊₁','الخطأ']),
 'secant': ('طريقة القاطع — إيجاد جذر', [('f','الدالة f(x)'),('x0','التخمين الأول x₀'),('x1','التخمين الثاني x₁'),('tol','التسامح ε'),('maxit','أقصى عدد تكرارات')], ['k','xₖ₋₁','xₖ','f(p)','p','الخطأ']),
 'diff': ('الاشتقاق العددي — أمامي/خلفي/مركزي', [('f','الدالة f(x)'),('x0','نقطة الاشتقاق x₀'),('h','خطوة h'),('mode','نوع الفرق: أمامي أو خلفي أو مركزي')], ['القيمة','النتيجة']),
 'jacobi': ('طريقة جاكوبي — حل نظام تكراري', [('A','مصفوفة المعاملات A (صف لكل سطر)'),('b','متجه الثوابت b'),('x0','التخمين الابتدائي (متجه)'),('tol','التسامح ε'),('maxit','أقصى عدد تكرارات')], ['k','x₁','x₂ …','الخطأ']),
 'lagrange': ('استيفاء لاغرانج — تقدير قيمة دالة', [('xs','قيم x (مفصولة بمسافات)'),('ys','قيم y المقابلة (مفصولة بمسافات)'),('x','النقطة المطلوب تقديرها')], ['i','xᵢ','yᵢ','Lᵢ(x)','المساهمة'])
}

class App:
    def __init__(self, root):
        self.root=root; self.root.title('الطرق العددية — واجهة تفاعلية'); self.root.geometry('1000x720'); self.root.minsize(760,560)
        self.style=ttk.Style(); self.style.configure('Treeview',rowheight=25,font=('Arial',10)); self.style.configure('Treeview.Heading',font=('Arial',10,'bold'))
        self.home()
    def clear(self):
        for w in self.root.winfo_children(): w.destroy()
    def home(self):
        self.clear(); outer=ttk.Frame(self.root,padding=22); outer.pack(fill='both',expand=True)
        ttk.Label(outer,text='الطرق العددية',font=('Arial',22,'bold')).pack(pady=(6,4))
        ttk.Label(outer,text='اختر الطريقة، أدخل البيانات، ثم اعرض النتيجة وجدول التتبّع.',font=('Arial',11)).pack(pady=(0,18))
        grid=ttk.Frame(outer); grid.pack(fill='x')
        for i,(key,(title,_,__)) in enumerate(METHODS.items()):
            ttk.Button(grid,text=title,command=lambda k=key:self.form(k)).grid(row=i//2,column=i%2,sticky='ew',padx=7,pady=6,ipady=10)
        grid.columnconfigure(0,weight=1); grid.columnconfigure(1,weight=1)
        ttk.Label(outer,text='الدوال الرياضية المدعومة: sin, cos, tan, exp, log, sqrt, abs, pi, e، واستخدم ^ أو ** للأس.',foreground='#555').pack(pady=14)
    def form(self,key):
        self.clear(); title,fields,cols=METHODS[key]; outer=ttk.Frame(self.root,padding=16); outer.pack(fill='both',expand=True)
        bar=ttk.Frame(outer); bar.pack(fill='x'); ttk.Button(bar,text='← الطرق',command=self.home).pack(side='left'); ttk.Label(bar,text=title,font=('Arial',16,'bold')).pack(side='right')
        form=ttk.Frame(outer); form.pack(fill='x',pady=12); self.inputs={}
        defaults={'f':'x^3 - x - 2','df':'','a':'1','b':'2','n':'8','tol':'1e-6','maxit':'100','x0':'1.5','x1':'2','h':'0.001','A':'4 1 1\n1 5 2\n1 2 6','xs':'0 1 2','ys':'1 2 5','x':'1.5'}
        defaults['b']='6 7 9' if key in ('kramer','gauss','jacobi') else '2'
        if key=='jacobi': defaults['x0']='0 0 0'
        for i,(name,label) in enumerate(fields):
            ttk.Label(form,text=label,anchor='e').grid(row=i,column=1,sticky='e',padx=7,pady=4)
            if name=='mode':
                w=ttk.Combobox(form,values=['مركزي','أمامي','خلفي'],state='readonly',width=52); w.set('مركزي')
            else:
                w=ttk.Entry(form,width=58)
                if name in defaults: w.insert(0,defaults[name])
            w.grid(row=i,column=0,sticky='ew',padx=7,pady=4); self.inputs[name]=w
        form.columnconfigure(0,weight=1)
        ttk.Button(outer,text='احسب واعرض جدول التتبّع',command=lambda:self.run(key,cols)).pack(pady=5)
        self.result=ttk.Label(outer,text='',font=('Arial',12,'bold'),foreground='#075e35',wraplength=900); self.result.pack(pady=7)
        tablebox=ttk.Frame(outer); tablebox.pack(fill='both',expand=True,pady=5)
        self.tree=ttk.Treeview(tablebox,show='headings'); self.tree.pack(side='left',fill='both',expand=True)
        sy=ttk.Scrollbar(tablebox,orient='vertical',command=self.tree.yview); sy.pack(side='right',fill='y'); self.tree.configure(yscrollcommand=sy.set)
        sx=ttk.Scrollbar(outer,orient='horizontal',command=self.tree.xview); sx.pack(fill='x'); self.tree.configure(xscrollcommand=sx.set)
    def run(self,key,cols):
        try:
            vals={k:w.get().strip() for k,w in self.inputs.items()}
            if any(not vals[k] for k in vals if k not in ('df',)): raise ValueError('يرجى تعبئة جميع الحقول المطلوبة.')
            result,trace=solve(key,vals)
            self.result.config(text=result)
            if key=='jacobi' and trace: cols=['k']+[f'x{i+1}' for i in range(len(trace[0])-2)]+['الخطأ']
            self.tree.delete(*self.tree.get_children()); self.tree['columns']=[f'c{i}' for i in range(len(cols))]
            for c,label in zip(self.tree['columns'],cols): self.tree.heading(c,text=label); self.tree.column(c,width=max(110,900//len(cols)),anchor='center',stretch=True)
            for row in trace: self.tree.insert('', 'end', values=row)
        except Exception as e: messagebox.showerror('تعذر الحساب',str(e))

if __name__ == '__main__':
    root=tk.Tk(); App(root); root.mainloop()
