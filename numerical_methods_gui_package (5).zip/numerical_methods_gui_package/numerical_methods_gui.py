import ast
import math
import tkinter as tk
from tkinter import ttk, messagebox

# Safe mathematical expression evaluator; supports x, standard math functions, and ^ as **.
_ALLOWED_FUNCS = {name: getattr(math, name) for name in
                  ('sin cos tan asin acos atan sinh cosh tanh exp log log10 sqrt'
                   ' floor ceil factorial radians degrees').split()}
_ALLOWED_FUNCS.update({'abs': abs, 'min': min, 'max': max})
_ALLOWED_CONSTS = {'pi': math.pi, 'e': math.e}

def f_eval(expr, x):
    tree = ast.parse(expr.replace('^', '**'), mode='eval')
    def ev(n):
        if isinstance(n, ast.Expression): return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)): return n.value
        if isinstance(n, ast.Name):
            if n.id == 'x': return x
            if n.id in _ALLOWED_CONSTS: return _ALLOWED_CONSTS[n.id]
            if n.id in _ALLOWED_FUNCS: return _ALLOWED_FUNCS[n.id]
            raise ValueError('اسم غير مسموح: ' + n.id)
        if isinstance(n, ast.BinOp) and type(n.op) in (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.Mod):
            a, b = ev(n.left), ev(n.right)
            return {ast.Add: lambda: a+b, ast.Sub: lambda: a-b, ast.Mult: lambda: a*b,
                    ast.Div: lambda: a/b, ast.Pow: lambda: a**b, ast.Mod: lambda: a%b}[type(n.op)]()
        if isinstance(n, ast.UnaryOp) and type(n.op) in (ast.UAdd, ast.USub):
            return ev(n.operand) if isinstance(n.op, ast.UAdd) else -ev(n.operand)
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in _ALLOWED_FUNCS:
            return _ALLOWED_FUNCS[n.func.id](*(ev(a) for a in n.args))
        raise ValueError('صيغة رياضية غير مدعومة')
    return float(ev(tree))

def rows_matrix(text):
    rows = [[float(v) for v in line.replace(',', ' ').split()] for line in text.strip().splitlines() if line.strip()]
    if not rows or any(len(r) != len(rows[0]) for r in rows): raise ValueError('أدخل المصفوفة صفاً في كل سطر وبأبعاد متساوية.')
    return rows

def determinant(a):
    m = [r[:] for r in a]; n = len(m); d = 1.0
    if any(len(r) != n for r in m): raise ValueError('المصفوفة يجب أن تكون مربعة.')
    for k in range(n):
        p = max(range(k, n), key=lambda i: abs(m[i][k]))
        if abs(m[p][k]) < 1e-14: return 0.0
        if p != k: m[k], m[p] = m[p], m[k]; d *= -1
        pivot = m[k][k]; d *= pivot
        for i in range(k+1, n):
            q = m[i][k] / pivot
            for j in range(k+1, n): m[i][j] -= q*m[k][j]
    return d

def parse_vector(text):
    return [float(v) for v in text.replace(',', ' ').split()]

def solve(method, v):
    trace, result = [], ''
    if method == 'kramer':
        a = rows_matrix(v['A']); b = parse_vector(v['b']); n = len(a)
        if len(b) != n or any(len(r) != n for r in a): raise ValueError('عدد عناصر b يجب أن يطابق أبعاد المصفوفة المربعة A.')
        d = determinant(a)
        if abs(d) < 1e-14: raise ValueError('المحدد يساوي صفراً؛ لا يوجد حل وحيد بطريقة كرامر.')
        x = []
        for j in range(n):
            aj = [r[:] for r in a]
            for i in range(n): aj[i][j] = b[i]
            dj = determinant(aj); x.append(dj/d)
            trace.append((f'x{j+1}', f'det(A{j+1}) = {dj:.8g}', f'x{j+1} = {dj:.8g} / {d:.8g} = {x[-1]:.8g}'))
        result = 'الحل: [' + ', '.join(f'{z:.10g}' for z in x) + ']'
    elif method == 'gauss':
        a = rows_matrix(v['A']); b = parse_vector(v['b']); n = len(a)
        if len(b) != n or any(len(r) != n for r in a): raise ValueError('أبعاد A و b غير متوافقة.')
        m = [a[i][:] + [b[i]] for i in range(n)]
        for k in range(n-1):
            p = max(range(k, n), key=lambda i: abs(m[i][k]))
            if abs(m[p][k]) < 1e-14: raise ValueError('النظام مفرد أو لا يملك حلاً وحيداً.')
            m[k], m[p] = m[p], m[k]
            for i in range(k+1, n):
                q = m[i][k]/m[k][k]
                for j in range(k, n+1): m[i][j] -= q*m[k][j]
            trace.append((f'حذف {k+1}', f'المحور = {m[k][k]:.6g}', ' | '.join(' '.join(f'{z:.5g}' for z in r) for r in m)))
        if abs(m[-1][-2]) < 1e-14: raise ValueError('النظام مفرد أو لا يملك حلاً وحيداً.')
        x = [0.0]*n
        for i in range(n-1, -1, -1): x[i] = (m[i][-1]-sum(m[i][j]*x[j] for j in range(i+1,n)))/m[i][i]
        trace.append(('تعويض خلفي', 'الحل', ', '.join(f'x{i+1}={z:.8g}' for i,z in enumerate(x))))
        result = 'الحل: [' + ', '.join(f'{z:.10g}' for z in x) + ']'
    elif method == 'trap':
        a,b,n = float(v['a']),float(v['b']),int(v['n']); expr=v['f']
        if n < 1: raise ValueError('n يجب أن يكون عدداً صحيحاً موجباً.')
        h=(b-a)/n; total=0.0
        for i in range(n+1):
            xx=a+i*h; yy=f_eval(expr,xx); w=0.5 if i in (0,n) else 1.0; part=w*yy; total+=part
            trace.append((i, f'{xx:.8g}', f'{yy:.8g}', f'{w:g}', f'{part:.8g}'))
        result=f'قيمة التكامل التقريبية = {h*total:.12g} (h = {h:.8g})'
    elif method in ('bisect','newton','secant'):
        expr=v['f']; tol=float(v['tol']); limit=int(v['maxit'])
        if tol<=0 or limit<1: raise ValueError('التسامح وعدد التكرارات يجب أن يكونا موجبين.')
        def ff(z): return f_eval(expr,z)
        if method=='bisect':
            a,b=float(v['a']),float(v['b']); fa,fb=ff(a),ff(b)
            if fa*fb>0: raise ValueError('يجب أن تتغير إشارة f بين a و b.')
            p=a
            for k in range(1,limit+1):
                p=(a+b)/2; fp=ff(p); err=abs(b-a)/2
                trace.append((k,f'{a:.8g}',f'{b:.8g}',f'{p:.10g}',f'{fp:.6g}',f'{err:.4g}'))
                if abs(fp)<tol or err<tol: break
                if fa*fp<0: b=p; fb=fp
                else: a=p; fa=fp
        elif method=='newton':
            x=float(v['x0']); de=v.get('df','').strip()
            def df(z): return f_eval(de,z) if de else (ff(z+1e-6)-ff(z-1e-6))/2e-6
            p=x
            for k in range(1,limit+1):
                fx=ff(x); dfx=df(x)
                if abs(dfx)<1e-14: raise ValueError('المشتقة تساوي صفراً؛ تعذر إكمال نيوتن.')
                p=x-fx/dfx; err=abs(p-x)
                trace.append((k,f'{x:.10g}',f'{fx:.6g}',f'{dfx:.6g}',f'{p:.10g}',f'{err:.4g}'))
                if abs(ff(p))<tol or err<tol: break
                x=p
        else:
            x0,x1=float(v['x0']),float(v['x1']); p=x1
            for k in range(1,limit+1):
                f0,f1=ff(x0),ff(x1); den=f1-f0
                if abs(den)<1e-14: raise ValueError('تعذر القسمة: قيمتا الدالة متساويتان تقريباً.')
                p=x1-f1*(x1-x0)/den; err=abs(p-x1)
                trace.append((k,f'{x0:.8g}',f'{x1:.8g}',f'{ff(p):.6g}',f'{p:.10g}',f'{err:.4g}'))
                if abs(ff(p))<tol or err<tol: break
                x0,x1=x1,p
        result=f'الجذر التقريبي = {p:.12g} ؛ f(x) = {ff(p):.5g} ؛ عدد التكرارات = {len(trace)}'
    elif method == 'diff':
        expr=v['f']; x=float(v['x0']); h=float(v['h']); mode=v['mode']
        if h==0: raise ValueError('h لا يجوز أن يساوي صفراً.')
        if mode=='مركزي': val=(f_eval(expr,x+h)-f_eval(expr,x-h))/(2*h)
        elif mode=='أمامي': val=(f_eval(expr,x+h)-f_eval(expr,x))/h
        else: val=(f_eval(expr,x)-f_eval(expr,x-h))/h
        trace=[('f(x)',f'{f_eval(expr,x):.10g}'),('f(x+h)',f'{f_eval(expr,x+h):.10g}'),('f(x-h)',f'{f_eval(expr,x-h):.10g}'),('h',h),('نوع الفرق',mode),('المشتقة التقريبية',f'{val:.12g}')]
        result=f"f'({x:g}) ≈ {val:.12g}"
    elif method == 'jacobi':
        a=rows_matrix(v['A']); b=parse_vector(v['b']); x=parse_vector(v['x0']); n=len(a); tol=float(v['tol']); limit=int(v['maxit'])
        if len(b)!=n or len(x)!=n or any(len(r)!=n for r in a): raise ValueError('أبعاد A و b والتخمين الابتدائي غير متوافقة.')
        if tol<=0 or limit<1: raise ValueError('التسامح وعدد التكرارات يجب أن يكونا موجبين.')
        for it in range(1,limit+1):
            xn=[]
            for i in range(n):
                if abs(a[i][i])<1e-14: raise ValueError('عنصر قطري صفري في A؛ لا يمكن تطبيق جاكوبي.')
                xn.append((b[i]-sum(a[i][j]*x[j] for j in range(n) if j!=i))/a[i][i])
            err=max(abs(xn[i]-x[i]) for i in range(n)); trace.append((it,*[f'{z:.8g}' for z in xn],f'{err:.4g}'))
            x=xn
            if err<tol: break
        result='الحل التقريبي: ['+', '.join(f'{z:.10g}' for z in x)+f'] ؛ عدد التكرارات = {len(trace)}'
    elif method == 'lagrange':
        xs=parse_vector(v['xs']); ys=parse_vector(v['ys']); x=float(v['x'])
        if len(xs)!=len(ys) or len(xs)<2: raise ValueError('يجب أن يتساوى عدد قيم x و y (قيمتان على الأقل).')
        if len(set(xs))!=len(xs): raise ValueError('قيم x يجب أن تكون مختلفة.')
        total=0.0
        for i in range(len(xs)):
            li=1.0
            for j in range(len(xs)):
                if i!=j: li *= (x-xs[j])/(xs[i]-xs[j])
            term=ys[i]*li; total+=term; trace.append((i+1,f'{xs[i]:g}',f'{ys[i]:g}',f'{li:.8g}',f'{term:.8g}'))
        result=f'P({x:g}) = {total:.12g}'
    return result, trace

METHODS = {
 'kramer': ('قاعدة كرامر — حل نظام خطي', [('A','مصفوفة A: صف لكل سطر'),('b','متجه الثوابت b')], ['المتغير','المحدد','الحساب']),
 'gauss': ('الحذف الغاوسي Gaussian Elimination', [('A','مصفوفة A: صف لكل سطر'),('b','متجه الثوابت b')], ['الخطوة','المحور/النتيجة','المصفوفة الموسعة']),
 'trap': ('قاعدة شبه المنحرف Trapezoidal Rule', [('f','الدالة f(x)'),('a','الحد الأدنى a'),('b','الحد الأعلى b'),('n','عدد الفترات n')], ['i','xᵢ','f(xᵢ)','الوزن','المساهمة']),
 'bisect': ('طريقة التنصيف Bisection', [('f','الدالة f(x)'),('a','a'),('b','b'),('maxit','عدد التكرارات n'),('tol','الخطأ ε')], ['k','a','b','p','f(p)','الخطأ']),
 'newton': ('طريقة نيوتن Newton', [('f','الدالة f(x)'),('df','المشتقة f′(x) — اختياري'),('x0','التخمين الابتدائي x₀'),('maxit','عدد التكرارات n'),('tol','الخطأ ε')], ['k','xₖ','f(xₖ)','f′(xₖ)','xₖ₊₁','الخطأ']),
 'secant': ('طريقة القاطع Secant', [('f','الدالة f(x)'),('x0','التخمين الأول x₀'),('x1','التخمين الثاني x₁'),('maxit','عدد التكرارات n'),('tol','الخطأ ε')], ['k','xₖ₋₁','xₖ','f(p)','p','الخطأ']),
 'diff': ('الاشتقاق العددي Numerical Differentiation', [('f','الدالة f(x)'),('x0','نقطة الاشتقاق x₀'),('h','خطوة h'),('mode','نوع الفرق')], ['القيمة','النتيجة']),
 'jacobi': ('طريقة جاكوبي Jacobi', [('A','مصفوفة A: صف لكل سطر'),('b','متجه الثوابت b'),('x0','التخمين الابتدائي (متجه)'),('maxit','عدد التكرارات n'),('tol','الخطأ ε')], ['k','x₁','x₂ …','الخطأ']),
 'lagrange': ('استيفاء لاغرانج Lagrange', [('xs','قيم x مفصولة بمسافات'),('ys','قيم y المقابلة'),('x','النقطة المطلوب تقديرها')], ['i','xᵢ','yᵢ','Lᵢ(x)','المساهمة'])
}

class App:
    def __init__(self, root):
        self.root=root; self.root.title('Numerical Methods'); self.root.geometry('760x760'); self.root.minsize(700,600)
        self.style=ttk.Style(); self.style.configure('Treeview',rowheight=25,font=('Arial',10)); self.style.configure('Treeview.Heading',font=('Arial',10,'bold'))
        self.style.configure('Big.TButton',font=('Arial',14,'bold'),padding=(10,10))
        self.home()
    def clear(self):
        for w in self.root.winfo_children(): w.destroy()
    def home(self):
        self.clear(); self.root.title('Numerical Methods'); outer=ttk.Frame(self.root,padding=28); outer.pack(fill='both',expand=True)
        ttk.Label(outer,text='Numerical Methods',font=('Arial',24,'bold')).pack(pady=(22,7))
        ttk.Label(outer,text='اختر الطريقة العددية',font=('Arial',13)).pack(pady=(0,25))
        buttons=ttk.Frame(outer); buttons.pack(fill='x',padx=55)
        main=[('bisect','طريقة التنصيف\nBisection'),('secant','طريقة القاطع\nSecant'),
              ('gauss','طريقة الحذف الغاوسي\nGaussian Elimination'),('jacobi','طريقة جاكوبي\nJacobi Method')]
        for key,label in main:
            ttk.Button(buttons,text=label,style='Big.TButton',command=lambda k=key:self.form(k)).pack(fill='x',pady=7,ipady=4)
        ttk.Button(outer,text='طرق إضافية من الملف (5)',command=self.more_methods).pack(pady=(18,4))
        ttk.Label(outer,text='يمكن إضافة الطرق الجديدة لاحقاً بسهولة',font=('Arial',10)).pack(pady=6)
    def more_methods(self):
        self.clear(); self.root.title('Numerical Methods'); outer=ttk.Frame(self.root,padding=26); outer.pack(fill='both',expand=True)
        bar=ttk.Frame(outer); bar.pack(fill='x')
        ttk.Button(bar,text='← الرئيسية',command=self.home).pack(side='left')
        ttk.Label(outer,text='طرق إضافية',font=('Arial',21,'bold')).pack(pady=(20,15))
        for key in ('kramer','trap','newton','diff','lagrange'):
            ttk.Button(outer,text=METHODS[key][0],style='Big.TButton',command=lambda k=key:self.form(k)).pack(fill='x',padx=65,pady=6)
    def form(self,key):
        title,fields,cols=METHODS[key]; self.clear(); self.root.title(title+' - Numerical Methods')
        outer=ttk.Frame(self.root,padding=20); outer.pack(fill='both',expand=True)
        ttk.Button(outer,text='← الرئيسية',command=self.home).pack(anchor='nw')
        ttk.Label(outer,text=title,font=('Arial',19,'bold')).pack(pady=(8,18))
        form=ttk.Frame(outer); form.pack(anchor='center',pady=8); self.inputs={}
        for i,(name,label) in enumerate(fields):
            ttk.Label(form,text=label,width=34,anchor='e',font=('Arial',10)).grid(row=i,column=0,sticky='e',padx=8,pady=9)
            if name=='mode':
                w=ttk.Combobox(form,values=['مركزي','أمامي','خلفي'],state='readonly',width=27); w.set('مركزي')
            elif name=='A':
                w=tk.Text(form,width=31,height=4,wrap='none',font=('Arial',10))
            else:
                w=ttk.Entry(form,width=29,font=('Arial',10))
            w.grid(row=i,column=1,sticky='w',padx=6,pady=9); self.inputs[name]=w
        ttk.Button(outer,text='حساب',width=22,command=lambda:self.run(key,cols)).pack(pady=(16,10))
        self.output=ttk.Frame(outer); self.output_visible=False
        self.result=ttk.Label(self.output,text='',font=('Arial',12,'bold'),foreground='#075e35',wraplength=900)
        tablebox=ttk.Frame(self.output); self.tree=ttk.Treeview(tablebox,show='headings',height=9)
        self.tree.pack(side='left',fill='both',expand=True)
        sy=ttk.Scrollbar(tablebox,orient='vertical',command=self.tree.yview); sy.pack(side='right',fill='y')
        self.tree.configure(yscrollcommand=sy.set)
        sx=ttk.Scrollbar(self.output,orient='horizontal',command=self.tree.xview)
        self.tree.configure(xscrollcommand=sx.set); self.tablebox=tablebox; self.xscroll=sx
    def run(self,key,cols):
        try:
            vals={k:(w.get('1.0','end').strip() if k=='A' else w.get().strip()) for k,w in self.inputs.items()}
            if any(not vals[k] for k in vals if k not in ('df',)): raise ValueError('يرجى تعبئة جميع الحقول المطلوبة.')
            result,trace=solve(key,vals)
            self.result.config(text=result)
            if key=='jacobi' and trace: cols=['k']+[f'x{i+1}' for i in range(len(trace[0])-2)]+['الخطأ']
            self.tree.delete(*self.tree.get_children()); self.tree['columns']=[f'c{i}' for i in range(len(cols))]
            for c,label in zip(self.tree['columns'],cols): self.tree.heading(c,text=label); self.tree.column(c,width=max(110,900//len(cols)),anchor='center',stretch=True)
            for row in trace: self.tree.insert('', 'end', values=row)
            if not self.output_visible:
                self.result.pack(pady=8); self.tablebox.pack(fill='both',expand=True,pady=5); self.xscroll.pack(fill='x')
                self.output.pack(fill='both',expand=True,pady=4); self.output_visible=True
        except Exception as e: messagebox.showerror('تعذر الحساب',str(e))

if __name__ == '__main__':
    root=tk.Tk(); App(root); root.mainloop()
